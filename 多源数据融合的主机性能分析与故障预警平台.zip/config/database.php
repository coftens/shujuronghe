<?php
/**
 * 数据库配置文件
 * 部署时请修改为实际的数据库连接信息
 */
return [
    'host'     => '127.0.0.1',
    'port'     => 3306,
    'dbname'   => 'host_monitor',
    'username' => 'host_monitor',
    'password' => 'your_password_here',
    'charset'  => 'utf8mb4',
];
